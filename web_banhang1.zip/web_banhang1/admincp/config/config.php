<?php 

	$mysqli = new mysqli("localhost","root","","web_lab456","3306");

	// Check connection
	if ($mysqli->connect_errno) {
	  echo "Kết nối MYSQLi lỗi" . $mysqli->connect_error;
	  exit();
	}

?>